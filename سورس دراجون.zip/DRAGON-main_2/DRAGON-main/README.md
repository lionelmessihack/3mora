
# DRAGON

# <p align="center" style="color:#cb3349" >سورس دراكون على تلكرام ⌯︙

# <p align="center" style="color:#cb3349" > شروحات عن السورس ادخل الى قناة السورس

# <p align="center" style="color:#cb3349" > [اصـــغـــط هــنـــا لــلــدخــول الــى الــقــنــاة](https://telegram.me/S0DRG) <br>

# <p align="center"> كود تنصيب السورس ⌯︙

 # <p align="center" style="color:#cb3349" > ``git clone https://github.com/SRC-DRAGON/DRAGON ;cd DRAGON;chmod +x install;./install``

# <p align="center"> بعد انتهاء عمليه تثبيت السورس ⌯︙

# <p align="center" style="color: #14635c;" >يطلب توكن البوت دخل توكن واضغط انتر ⌯︙

 

# <p align="center" style="color:#cb3349" > وراها راح يطلب منك ايدي المطور الاساسي دخله واضغط انتر ⌯︙

# <p align="center" style="color:#cb3349" > ⌯︙للمشاكل والاسفسار والاقتراحات :

  

# <p align="center" style="color:#cb3349" > [مــطــور ســورس](https://telegram.me/s00f4) <br>
 
 
 
# <p align="center" style="color:#cb3349" > [مبــرمـج دراكون](https://telegram.me/mndzr) <br>

  

  

# <p align="center" style="color:#cb3349" > [كـــروب  مــود](https://t.me/joinchat/APVPGU43ZnxKwJGnuBKDww) <br>
